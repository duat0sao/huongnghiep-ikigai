<?php
$error=$_GET['error'];
echo "<p class=' text-center col-sm-2' style='color:red'>$error</p>";
?>