

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Holland</title>
        <link rel="stylesheet" href="style.css">
        
    </head>
    <body>
<div class="container">
     
<div class="row justify-content-center hang">
<form method="post" action="xuly1.php" id="form-1">
    <h2>Trắc ngiệm Holland</h2>

    <!-- câu 1 bộ 1-->
    <div class="form-group1 id1">
        <h4>Tôi có tính tự lập</h4>
        <div>
            
            <input type="radio" name="cau1"  value="0">
            <label>Bạn thấy ý đó chưa bao giờ đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau1" value="1">
            <label>Bạn thấy ý đó chỉ đúng trong một vài trường hợp</label>
        </div>
        <div>
            
            <input type="radio" name="cau1" value="2">
            <label>Bạn thấy ý đó chỉ một nửa là đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau1" value="3">
            <label>Bạn thấy ý đó gần như là đúng với bạn trong hầu hết mọi trường hợp</label>
        </div>
        <div>
            
            <input type="radio" name="cau1" value="4">
            <label>Bạn thấy ý đó là hoàn toàn đúng với bạn, không thể nào khác đi được</label>
        </div>
        
    </div>

    <!-- câu 2 bộ 1-->
    <div class="form-group1 id2 hide">
        <h4>Tôi suy nghĩ thực tế</h4>
        <div>
            
            <input type="radio" name="cau2"  value="0">
            <label>Bạn thấy ý đó chưa bao giờ đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau2" value="1">
            <label>Bạn thấy ý đó chỉ đúng trong một vài trường hợp</label>
        </div>
        <div>
            
            <input type="radio" name="cau2" value="2">
            <label>Bạn thấy ý đó chỉ một nửa là đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau2" value="3">
            <label>Bạn thấy ý đó gần như là đúng với bạn trong hầu hết mọi trường hợp, chỉ có một vài trường hợp là chưa đúng lắm</label>
        </div>
        <div>
            
            <input type="radio" name="cau2" value="4">
            <label>Bạn thấy ý đó là hoàn toàn đúng với bạn, không thể nào khác đi được</label>
        </div>
        
    </div>

    <!-- câu 3 bộ 1-->
    <div class="form-group1 id3 hide">
        <h4>Tôi là người thích nghi với môi trường mới</h4>
        <div>
            
            <input type="radio" name="cau3"  value="0">
            <label>Bạn thấy ý đó chưa bao giờ đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau3" value="1">
            <label>Bạn thấy ý đó chỉ đúng trong một vài trường hợp</label>
        </div>
        <div>
            
            <input type="radio" name="cau3" value="2">
            <label>Bạn thấy ý đó chỉ một nửa là đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau3" value="3">
            <label>Bạn thấy ý đó gần như là đúng với bạn trong hầu hết mọi trường hợp, chỉ có một vài trường hợp là chưa đúng lắm</label>
        </div>
        <div>
            
            <input type="radio" name="cau3" value="4">
            <label>Bạn thấy ý đó là hoàn toàn đúng với bạn, không thể nào khác đi được</label>
        </div>
        
    </div>

    <!-- câu 4 bộ 1-->
    <div class="form-group1 id4 hide">
        <h4>Tôi có thể vận hành, điều khiển các máy móc thiết bị</h4>
        <div>
            
            <input type="radio" name="cau4"  value="0">
            <label>Bạn thấy ý đó chưa bao giờ đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau4" value="1">
            <label>Bạn thấy ý đó chỉ đúng trong một vài trường hợp</label>
        </div>
        <div>
            
            <input type="radio" name="cau4" value="2">
            <label>Bạn thấy ý đó chỉ một nửa là đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau4" value="3">
            <label>Bạn thấy ý đó gần như là đúng với bạn trong hầu hết mọi trường hợp, chỉ có một vài trường hợp là chưa đúng lắm</label>
        </div>
        <div>
            
            <input type="radio" name="cau4" value="4">
            <label>Bạn thấy ý đó là hoàn toàn đúng với bạn, không thể nào khác đi được</label>
        </div>
        
    </div>


    <!-- câu 5 bộ 1-->
    <div class="form-group1 id5 hide">
        <h4>Tôi có thể vận hành, điều khiển các máy móc thiết bị</h4>
        <div>
            
            <input type="radio" name="cau5"  value="0">
            <label>Bạn thấy ý đó chưa bao giờ đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau5" value="1">
            <label>Bạn thấy ý đó chỉ đúng trong một vài trường hợp</label>
        </div>
        <div>
            
            <input type="radio" name="cau5" value="2">
            <label>Bạn thấy ý đó chỉ một nửa là đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau5" value="3">
            <label>Bạn thấy ý đó gần như là đúng với bạn trong hầu hết mọi trường hợp, chỉ có một vài trường hợp là chưa đúng lắm</label>
        </div>
        <div>
            
            <input type="radio" name="cau5" value="4">
            <label>Bạn thấy ý đó là hoàn toàn đúng với bạn, không thể nào khác đi được</label>
        </div>
        
    </div>

    <!-- câu 6 bộ 1-->
    <div class="form-group1 id6 hide">
        <h4>Tôi có thể vận hành, điều khiển các máy móc thiết bị</h4>
        <div>
            
            <input type="radio" name="cau6"  value="0">
            <label>Bạn thấy ý đó chưa bao giờ đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau6" value="1">
            <label>Bạn thấy ý đó chỉ đúng trong một vài trường hợp</label>
        </div>
        <div>
            
            <input type="radio" name="cau6" value="2">
            <label>Bạn thấy ý đó chỉ một nửa là đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau6" value="3">
            <label>Bạn thấy ý đó gần như là đúng với bạn trong hầu hết mọi trường hợp, chỉ có một vài trường hợp là chưa đúng lắm</label>
        </div>
        <div>
            
            <input type="radio" name="cau6" value="4">
            <label>Bạn thấy ý đó là hoàn toàn đúng với bạn, không thể nào khác đi được</label>
        </div>
        
    </div>

    <!-- câu 7 bộ 1-->
    <div class="form-group1 id7 hide">
        <h4>Tôi có thể vận hành, điều khiển các máy móc thiết bị</h4>
        <div>
            
            <input type="radio" name="cau7"  value="0">
            <label>Bạn thấy ý đó chưa bao giờ đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau7" value="1">
            <label>Bạn thấy ý đó chỉ đúng trong một vài trường hợp</label>
        </div>
        <div>
            
            <input type="radio" name="cau7" value="2">
            <label>Bạn thấy ý đó chỉ một nửa là đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau7" value="3">
            <label>Bạn thấy ý đó gần như là đúng với bạn trong hầu hết mọi trường hợp, chỉ có một vài trường hợp là chưa đúng lắm</label>
        </div>
        <div>
            
            <input type="radio" name="cau7" value="4">
            <label>Bạn thấy ý đó là hoàn toàn đúng với bạn, không thể nào khác đi được</label>
        </div>
        
    </div>

    <!-- câu 8 bộ 1-->
    <div  class="form-group1 id8 hide">
        <h4>Tôi có thể vận hành, điều khiển các máy móc thiết bị</h4>
        <div>
            
            <input type="radio" name="cau8"  value="0">
            <label>Bạn thấy ý đó chưa bao giờ đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau8" value="1">
            <label>Bạn thấy ý đó chỉ đúng trong một vài trường hợp</label>
        </div>
        <div>
            
            <input type="radio" name="cau8" value="2">
            <label>Bạn thấy ý đó chỉ một nửa là đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau8" value="3">
            <label>Bạn thấy ý đó gần như là đúng với bạn trong hầu hết mọi trường hợp, chỉ có một vài trường hợp là chưa đúng lắm</label>
        </div>
        <div>
            
            <input type="radio" name="cau8" value="4">
            <label>Bạn thấy ý đó là hoàn toàn đúng với bạn, không thể nào khác đi được</label>
        </div>
        
    </div>

    <!-- câu 9 bộ 1-->
    <div class="form-group1 id9 hide">
        <h4>Tôi có thể vận hành, điều khiển các máy móc thiết bị</h4>
        <div>
            
            <input type="radio" name="cau9"  value="0">
            <label>Bạn thấy ý đó chưa bao giờ đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau9" value="1">
            <label>Bạn thấy ý đó chỉ đúng trong một vài trường hợp</label>
        </div>
        <div>
            
            <input type="radio" name="cau9" value="2">
            <label>Bạn thấy ý đó chỉ một nửa là đúng với bạn</label>
        </div>
        <div>
            
            <input type="radio" name="cau9" value="3">
            <label>Bạn thấy ý đó gần như là đúng với bạn trong hầu hết mọi trường hợp, chỉ có một vài trường hợp là chưa đúng lắm</label>
        </div>
        <div>
            
            <input type="radio" name="cau9" value="4">
            <label>Bạn thấy ý đó là hoàn toàn đúng với bạn, không thể nào khác đi được</label>
        </div>
        
    </div>

   
    	


   
    <input type="submit" value="Gửi">
    
</form>

</div>
</div>

 
    </body>
</html>